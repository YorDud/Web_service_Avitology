declare module "yookassa";
